import React from 'react';
import './Spinner.styles.css';

const Spinner = () => (
  <div className="loader"></div>
)

export default Spinner;